﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace MileStone2
{
    class Datahandler
    {
        #region parameterless Constructor


        public Datahandler()
        {

        }

        #endregion


        #region Connect
        string connect = "Data Source=.; Initial Catalog=BelgiumCampus; Integrated Security = SSPI";
        SqlConnection conn; 
        SqlCommand cmd;

        #endregion


        #region student
        Student objStudent = new Student();


        #endregion


        #region Save
        public void Add(int StudentID, string Name, string Surname, int DateOfBirth, string Gender, int Phone, int Address, int Fees, double Payment, string ModuleCode)
        {
            try
            {
                                        
                string query = @"INSERT INTO tblStudent VALUES(" + StudentID + " ,'" + Name + "' ,'" + Surname + "','" + Gender + "'," + DateOfBirth + "'," + Phone + "'," + Address + "' ,'" + ModuleCode + "')";
               
                conn = new SqlConnection(connect);
                conn.Open();
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Details Added Successfully.");
            }
            catch (Exception)
            {

                MessageBox.Show("Details not Added");

            }

        }

        #endregion

        #region Update
        public void Update(int StudentID, string Name, string Surname, int DateOfBirth, string Gender, int Phone, int Address, int Fees, double Payment, string ModuleCode)
        {
            try
            {
                string query = @"UPDATE tblStudent VALUES(" + StudentID + " ,'" + Name + "' ,'" + Surname + "','" + Gender + "'," + DateOfBirth + ")";
                conn = new SqlConnection(connect);
                conn.Open();
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Details Successfully Updated");


            }
            catch (Exception ex)
            {

                MessageBox.Show("Details not saved!..");
            }
        }

        #endregion


        #region deleteStudent

        public void DeleteStudent(int StudentID)
        {
            try
            {
                string query = @"DELETE FROM tblStudent WHERE StudentID = ('" + StudentID + " ')";
                conn = new SqlConnection(connect);
                conn.Open();
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted the details of student with ID number of :{0},StudentID");
                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error!!!" + ex.Message);
            }

        }

        #endregion


        #region ViewAll


        private void btnShowAll(int StudentID)
        {
            try
            {
                string connect = @"DataSource=.;Initial Catalog=Belgiumcampus;Integrated Security=SSPI";
                SqlConnection conn = new SqlConnection(connect);
                conn.Open();
                string query = @"Select * from tbl Student";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvStudentRecords.DataSource = dt;
                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            
        }

        #endregion

        #region Search


        private void btnSearch_Click(int StudentID)
        {
            try
            {
                foreach (DataGridViewRow row in dgvStudentRecords.Rows)
                {
                    if (row.Cells[2].Value.ToString().Equals(searchValue))
                    {
                        row.Selected = true;
                        break;
                    }
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }

        }

        #endregion


    }
}
